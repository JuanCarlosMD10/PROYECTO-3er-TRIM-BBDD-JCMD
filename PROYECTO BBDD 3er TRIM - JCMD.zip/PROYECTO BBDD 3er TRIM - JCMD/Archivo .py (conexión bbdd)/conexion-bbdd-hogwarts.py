# Proyecto BBDD -> conexion-bbdd-hogwarts.py
# author: Juan Carlos Mejías Doñoro

import pymongo
cliente = pymongo.MongoClient("localhost", 27017)
base_de_datos = cliente["hogwarts"]
coleccion_personajes = base_de_datos["personajes"]
coleccion_lugares = base_de_datos["lugares"]
coleccion_hechizos = base_de_datos["hechizos"]
coleccion_criaturas = base_de_datos["criaturas"]

###########################################################################################

# CONSULTAS

# Consulta de búsqueda: Encontrar todos los personajes que nacieron en el mes de julio
resultados_busqueda = coleccion_personajes.find({"fecha_nacimiento": {"$regex": ".* de julio.*"}})
print("Personajes nacidos en el mes de julio:")
for resultado in resultados_busqueda:
    print(resultado["nombre"])

# Consulta de búsqueda: Encontrar todos los personajes que pertenecen a la casa Gryffindor
personajes_gryffindor = coleccion_personajes.find({"casa": "Slytherin"})
print("\nPersonajes pertenecientes a la casa Slytherin:")
for personaje in personajes_gryffindor:
    print(personaje["nombre"])

# Consulta de búsqueda: Encontrar todos los hechizos de nivel avanzado
hechizos_avanzados = coleccion_hechizos.find({"nivel_dificultad": "Intermedio"})
print("\nHechizos intermedios:")
for hechizo in hechizos_avanzados:
    print(hechizo["nombre"])

# Consulta de búsqueda: Encontrar todos los personajes que son Mortífagos.
mortifagos_relaciones = coleccion_personajes.find({"roles": "Mortífago"})
print("\nPersonajes mortífagos:")
for personaje in mortifagos_relaciones:
    print(personaje["nombre"])

# Buscar todos los lugares que contienen el hechizo "Alohomora"
lugares_con_alohomora = coleccion_lugares.find({"hechizos_usados": "Alohomora"}, {"nombre": 1, "_id": 0})
print("\nNombres de los lugares en los que se ha usado el hechizo 'Alohomora':")
for lugar in lugares_con_alohomora:
    print(lugar["nombre"])

###########################################################################################

# AGREGACIONES

# Agregación para calcular el número total de personajes en la base de datos
agregacion_numero_total_personajes = coleccion_personajes.aggregate([
    {"$group": {"_id": None, "total": {"$sum": 1}}}
])
for resultado in agregacion_numero_total_personajes:
    numero_total_personajes = resultado["total"]
print("\nNúmero total de personajes en la base de datos:", numero_total_personajes)


# Agregación: Contar el número de hechizos en cada nivel de dificultad
print("\nCantidad de hechizos según la dificultad:")
agregacion_dificultad_hechizos = coleccion_hechizos.aggregate([
    {"$group": {"_id": "$nivel_dificultad", "cantidad": {"$sum": 1}}},
    {"$match": {"_id": {"$ne": None}}}
])
for resultado in agregacion_dificultad_hechizos:
    print(resultado)

# Agregación: Encontrar la casa con más miembros
print("\nNombre y cantidad de la casa con más miembros:")
agregacion_casa_miembros = coleccion_personajes.aggregate([
    {"$group": {"_id": "$casa", "cantidad": {"$sum": 1}}},
    {"$sort": {"cantidad": -1}},
    {"$limit": 1}
])
for resultado in agregacion_casa_miembros:
    print(resultado)

# Agregación: Encontrar la cantidad total de hechizos usados en cada lugar.
print("\nCantidad de hechizos usados en cada lugar:")
agregacion_hechizos_por_lugar = coleccion_lugares.aggregate([
    {"$unwind": "$hechizos_usados"},
    {"$group": {"_id": "$nombre", "total_hechizos": {"$sum": 1}}}
])
for resultado in agregacion_hechizos_por_lugar:
    print(resultado)

# Utilizar agregación para buscar todas las criaturas que habitan en bosques y montañas
print("\nCriaturas que habitan en bosques y montañas:")
agregacion_bosques_montañas = coleccion_criaturas.aggregate([
    {"$match": {"habitat": "Bosques y montañas"}},
    {"$project": {"_id": 0, "nombre": 1}}
])
for criatura in agregacion_bosques_montañas:
    print(criatura["nombre"])


# Cerrar la conexión con MongoDB
cliente.close()